export const AppConstants = {
  BASE_URL: 'http://localhost:3000/',
  COUNTRIES_API: 'countries',
  PRODUCTS_API: 'products'
};
